#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dir.h>
#include <time.h>

struct FLM6
{
	char	dict[6];
	char	flag[6][7];
	char	answer[6][7];
} flm6 =
{
	"103N59",

	"101000",
	"000101",
	"100101",
	"000101",
	"100001",
	"100110",

	"123456",
	"123456",
	"123456",
	"123456",
	"123456",
	"123456",

};

void emptyanswer(void)
{
	memset( flm6.answer[0], ' ', 6 );
	memset( flm6.answer[1], ' ', 6 );
	memset( flm6.answer[2], ' ', 6 );
	memset( flm6.answer[3], ' ', 6 );
	memset( flm6.answer[4], ' ', 6 );
	memset( flm6.answer[5], ' ', 6 );
}

int answergetnot( char *not, char method )
{ // 1~6=h, a~f=v, A~F=gong.
	int i;
	char tmp[6];
	switch ( method )
	{
	case 'a':
	case 'b':
	case 'c':
	case 'd':
	case 'e':
	case 'f':
		tmp[0]=flm6.answer[0][method-'a'];
		tmp[1]=flm6.answer[1][method-'a'];
		tmp[2]=flm6.answer[2][method-'a'];
		tmp[3]=flm6.answer[3][method-'a'];
		tmp[4]=flm6.answer[4][method-'a'];
		tmp[5]=flm6.answer[5][method-'a'];
		break;
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
		memcpy( tmp, flm6.answer[method-'1'], 6 );
		break;
	case 'A':
	case 'C':
	case 'E':
		memcpy( tmp, flm6.answer[method-'A'], 3 );
		memcpy( tmp+3, flm6.answer[method-'A'+1], 3 );
		break;
	case 'B':
	case 'D':
	case 'F':
		memcpy( tmp, flm6.answer[method-'B']+3, 3 );
		memcpy( tmp+3, flm6.answer[method-'B'+1]+3, 3 );
		break;
	}
	memset( not, 0, 7 );
	for (i=0; i<6; i++ )
	if ( tmp[i] >= '1' && tmp[i] <='6' )
		not[strlen(not)] = tmp[i];
	return strlen(not);
}

int answergetnotequ( char* not, char method )
{
	int i, ret = answergetnot( not, method );
	if ( ret == 6 )
	{
		for ( i='1'; i<='6'; i++ )
			if ( strchr( not, i ) == NULL ) return 0;
	}	return ret;
}

char random6not( char* not )
{
	char c;
	int i, n= strlen(not);
	c = random( 6 ) + '1';
	for ( i=0; i<n; i++ )
		if ( not[i] == c ) break;
	if ( i==n )
		return c;
	return random6not( not );
}

int mixnot( char* n1, char* n2 )
{
	int i, j;
	for ( i=0; i<strlen(n1); i++ )
	if ( strchr( n2, n1[i] ) == NULL )
		*(short*)(n2+strlen(n2))=(short)(n1[i]);
        return strlen( n2 );
}


int randomflm6( int gong )
{
	int i;
	char not[7], n1[7], n2[7], *pn2;
	switch (gong)
	{
	case 0:
		emptyanswer();
		randomflm6(1);
		randomflm6(2);
		randomflm6(3);
		randomflm6(4);
		randomflm6(5);
		randomflm6(6);
		break;
	case 1:
		answergetnot( not, 'A' );
		flm6.answer[0][0] = random6not( not );
		answergetnot( not, 'A' );
		flm6.answer[0][1] = random6not( not );
		answergetnot( not, 'A' );
		flm6.answer[0][2] = random6not( not );
		answergetnot( not, 'A' );
		flm6.answer[1][0] = random6not( not );
		answergetnot( not, 'A' );
		flm6.answer[1][1] = random6not( not );
		answergetnot( not, 'A' );
		flm6.answer[1][2] = random6not( not );
		break;
	case 2:
		answergetnot( not, '1' );
		flm6.answer[0][3] = random6not( not );
		answergetnot( not, '1' );
		flm6.answer[0][4] = random6not( not );
		answergetnot( not, '1' );
		flm6.answer[0][5] = random6not( not );
		answergetnot( not, '2' );
		flm6.answer[1][3] = random6not( not );
		answergetnot( not, '2' );
		flm6.answer[1][4] = random6not( not );
		answergetnot( not, '2' );
		flm6.answer[1][5] = random6not( not );
		break;
	case 3:
		answergetnot( not, 'a' );
		flm6.answer[2][0] = random6not( not );
		answergetnot( n1,  'C' );
		answergetnot( not, 'b' );
		mixnot( n1, not );
		flm6.answer[2][1] = random6not( not );
		answergetnot( n1,  'C' );
		answergetnot( not, 'c' );
		mixnot( n1, not );
		flm6.answer[2][2] = random6not( not );
		answergetnot( n1,  'C' );
		answergetnot( not, 'a' );
		mixnot( n1, not );
		flm6.answer[3][0] = random6not( not );
		answergetnot( n1,  'C' );
		answergetnot( not, 'b' );
		if ( mixnot( n1, not ) < 6 )
			flm6.answer[3][1] = random6not( not );
		else
		{
			flm6.answer[3][1] = flm6.answer[3][0];
			flm6.answer[3][0] = ' ';
			answergetnot( n1,  'C' );
			answergetnot( not, 'a' );
			mixnot( n1, not );
			flm6.answer[3][0] = random6not( not );
		}
		answergetnot( n1,  'C' );
		answergetnot( not, 'c' );
		if ( mixnot( n1, not ) < 6 )
			flm6.answer[3][2] = random6not( not );
		else
		{	// check the last 2 digi.
			if ( flm6.answer[3][1] != flm6.answer[0][2] &&
			     flm6.answer[3][1] != flm6.answer[1][2] )
			{
				flm6.answer[3][2] = flm6.answer[3][1];
				flm6.answer[3][1] = ' ';
				answergetnot( not,  'C' );
				flm6.answer[3][1] = random6not( not );
			} else
			if ( flm6.answer[3][0] != flm6.answer[0][2] &&
			     flm6.answer[3][0] != flm6.answer[1][2] )
			{
				flm6.answer[3][2] = flm6.answer[3][0];
				flm6.answer[3][0] = ' ';
				answergetnot( not,  'C' );
				flm6.answer[3][0] = random6not( not );
		}	} 
		break;
	case 4:
		answergetnot( not, '3' );
		answergetnot( n1,  'd' );
		mixnot( n1, not );
		flm6.answer[2][3] = random6not( not );
		answergetnot( not, '3' );
		answergetnot( n1,  'e' );
		if ( mixnot( n1, not ) < 6 )
			flm6.answer[2][4] = random6not( not );
		else
		{
			flm6.answer[2][4] = flm6.answer[2][3];
			flm6.answer[2][3] = ' ';
			answergetnot( not, '3' );
			answergetnot( n1,  'd' );
			mixnot( n1, not );
			flm6.answer[2][3] = random6not( not );
		}
		answergetnot( not, '3' );
		answergetnot( n1,  'f' );
		if( mixnot( n1, not ) < 6 )
			flm6.answer[2][5] = random6not( not );
		else
		{
			flm6.answer[2][5] = flm6.answer[2][4];
			flm6.answer[2][4] = ' ';
			answergetnot( not, '3' );
			answergetnot( n1,  'e' );
			mixnot( n1, not );
			flm6.answer[2][4] = random6not( not );
		}
		answergetnot( not, '4' );
		answergetnot( n1,  'd' );
		mixnot( n1, not );
		flm6.answer[3][3] = random6not( not );
		answergetnot( not, '4' );
		answergetnot( n1,  'e' );
		if ( mixnot( n1, not ) < 6 )
			flm6.answer[3][4] = random6not( not );
		else
		{
			flm6.answer[3][4] = flm6.answer[3][3];
			flm6.answer[3][3] = ' ';
			answergetnot( not, '4' );
			answergetnot( n1,  'd' );
			mixnot( n1, not );
			flm6.answer[3][3] = random6not( not );
		}
		answergetnot( not, '4' );
		answergetnot( n1,  'f' );
		if( mixnot( n1, not ) < 6 )
			flm6.answer[3][5] = random6not( not );
		else
		{
			if ( flm6.answer[3][4] != flm6.answer[0][5] &&
			     flm6.answer[3][4] != flm6.answer[1][5] )
			{
				flm6.answer[3][5] = flm6.answer[3][4];
				flm6.answer[3][4] = ' ';
				answergetnot( not, '4' );
				answergetnot( n1,  'e' );
				mixnot( n1, not );
				flm6.answer[3][4] = random6not( not );
			} else
			if ( flm6.answer[3][3] != flm6.answer[0][5] &&
			     flm6.answer[3][3] != flm6.answer[1][5] )
			{
				flm6.answer[3][5] = flm6.answer[3][3];
				flm6.answer[3][3] = ' ';
				answergetnot( not, 'D' );
				flm6.answer[3][3] = random6not( not );
		}	}
		break;
	case 5:
		answergetnot( not, 'a' );
		flm6.answer[4][0] = random6not( not );
		answergetnot( n1,  'E' );
		answergetnot( not, 'b' );
		mixnot( n1, not );
		flm6.answer[4][1] = random6not( not );
		answergetnot( n1,  'E' );
		answergetnot( not, 'c' );
		mixnot( n1, not );
		flm6.answer[4][2] = random6not( not );
		answergetnot( not, 'a' );
		flm6.answer[5][0] = random6not( not );
		answergetnot( not, 'b' );
		flm6.answer[5][1] = random6not( not );
		answergetnot( not, 'c' );
		flm6.answer[5][2] = random6not( not );
		break;
	case 6:
		answergetnot( not, '5' );
		answergetnot( n1,  'd' );
		if ( mixnot( n1, not ) < 6 )
			flm6.answer[4][3] = random6not( not );
		else
		{	flm6.answer[4][3] = flm6.answer[4][2];
			flm6.answer[4][2] = flm6.answer[5][2];
			flm6.answer[5][2] = flm6.answer[4][3];
		}
		answergetnot( not, '6' );
		answergetnot( n1,  'd' );
		mixnot( n1, not );
		if( mixnot( n1, not ) < 6 )
			flm6.answer[5][3] = random6not( not );
		else
		{
			flm6.answer[5][3] = flm6.answer[4][3];
			flm6.answer[4][3] = ' ';
			answergetnot( not, '5' );
			answergetnot( n1,  'd' );
			mixnot( n1, not );
			flm6.answer[4][3] = random6not( not );
			// check the next line.
			strncpy( n2, flm6.answer[5], 3 );
			n2[3]=0;
			pn2 = strchr( n2, flm6.answer[5][3] );
			if ( pn2 != NULL )
			{	// exchange the number.
				i = pn2 - n2;
				flm6.answer[5][i] = flm6.answer[4][i];
				flm6.answer[4][i] = flm6.answer[5][3];
		}       }
		answergetnot( not, '5' );
		answergetnot( n1,  'e' );
		if( mixnot( n1, not ) < 6 )
			flm6.answer[4][4] = random6not( not );
		else
		{
			flm6.answer[4][4] = flm6.answer[4][2];
			flm6.answer[4][2] = flm6.answer[5][2];
			flm6.answer[5][2] = flm6.answer[4][4];
		}
		answergetnot( not, '5' );
		flm6.answer[4][5] = random6not( not );
		answergetnot( not, 'e' );
		flm6.answer[5][4] = random6not( not );
		answergetnot( not, 'f' );
		flm6.answer[5][5] = random6not( not );
		break;
	}
	return 0; // success.
}

char *screen[6*4+1] =
{
	"++===+===+===++===+===+===++",
	"||   |   |   ||   |   |   ||",
	"|| 1 | 0 | 0 || 0 | 0 | 0 ||",
	"||   |   |   ||   |   |   ||",
	"++---+---+---++---+---+---++",
	"||   |   |   ||   |   |   ||",
	"|| 2 | 0 | 0 || 0 | 0 | 0 ||",
	"||   |   |   ||   |   |   ||",
	"++===+===+===++===+===+===++",
	"||   |   |   ||   |   |   ||",
	"|| 3 | 0 | 0 || 0 | 0 | 0 ||",
	"||   |   |   ||   |   |   ||",
	"++---+---+---++---+---+---++",
	"||   |   |   ||   |   |   ||",
	"|| 4 | 0 | 0 || 0 | 0 | 0 ||",
	"||   |   |   ||   |   |   ||",
	"++===+===+===++===+===+===++",
	"||   |   |   ||   |   |   ||",
	"|| 5 | 0 | 0 || 0 | 0 | 0 ||",
	"||   |   |   ||   |   |   ||",
	"++---+---+---++---+---+---++",
	"||   |   |   ||   |   |   ||",
	"|| 6 | 0 | 0 || 0 | 0 | 0 ||",
	"||   |   |   ||   |   |   ||",
	"++===+===+===++===+===+===++",
};

char* screenxy( char x, char y )
{
	char *p;
	if ( x >= 'a' && x <= 'f' &&
	     y >= '1' && y <= '6' )
	{
		x -= 'a';
		y -= '1';
		p =  screen[2+y*4];
		p += 4+4*x-1;
		if ( x >= 3 ) p++;
		return p;
	}
	return NULL;
}

void paintflm6( int method )	// 01(answer) 10(question) 11(q&a)
{
	int i,x,y;
	char* p, ln[6*4+1][80];
	// erase the screen.
	for ( y='1'; y<='6'; y++ )
	for ( x='a'; x<='f'; x++ )
		if ( ( p = screenxy( x, y ) ) != NULL )
			*p = ' ';
	// paint flag.
	for ( y='1'; y<='6'; y++ )
	for ( x='a'; x<='f'; x++ )
		if ( ( p = screenxy( x, y ) ) != NULL )
		if ( flm6.flag[y-'1'][x-'a'] == '1' )
			*p = flm6.answer[y-'1'][x-'a'];
	for ( y=0; y<6*4+1; y++ )
		sprintf( ln[y], "%s\t", screen[y] );
	// paint answer.
	for ( y='1'; y<='6'; y++ )
	for ( x='a'; x<='f'; x++ )
		if ( ( p = screenxy( x, y ) ) != NULL )
			*p = flm6.answer[y-'1'][x-'a'];
	for ( y=0; y<6*4+1; y++ )
	{
		// replace the paint char. 103N59
		for ( i=0; i<strlen(ln[y]); i++ )
		if ( ln[y][i] >= '1' && ln[y][i] <= '6' )
		{
			ln[y][i] -= '1';
			ln[y][i] = flm6.dict[ln[y][i]];
		}
		for ( i=0; i<strlen(screen[y]); i++ )
		if ( screen[y][i] >= '1' && screen[y][i] <= '6' )
		{
			screen[y][i] -= '1';
			screen[y][i] = flm6.dict[screen[y][i]];
		}
		// print the result.
		switch (method)
		{
		case 1:
			printf( "\t%s\n", screen[y] );
			break;
		case 2:
			printf( "\t%s\n", ln[y] );
			break;
		case 3:
			printf( "\t%s%s\n", ln[y], screen[y] );
			break;
		}
	}
}

void main( int argc, char* argv[] )
{
	int i=0, j;
	char not[7];
	if ( argc > 1 )
		sscanf( argv[1], "%d", &i );
	// randomize
	randomize();


	clrscr();
	while ( 1 )
	{
		gotoxy( 1, 1 );
	 //       if ( i == 0 )
	 //		;
	 //	else
	 //		printf( "%d", i );
		//
		printf( "\n\nFlamedoku Encode programming...\n\n" );

		randomflm6(0);
		paintflm6( 1 );
	 /*	// check each line and array and gong.
		for ( j='a'; j<='f'; j++ )
			if ( answergetnotequ( not, j ) == 6 )
				printf( " %c", j );
		printf( "\n" );
		for ( j='1'; j<='6'; j++ )
			if ( answergetnotequ( not, j ) == 6 )
				printf( " %c", j );
		printf( "\n" );
		for ( j='A'; j<='F'; j++ )
			if ( answergetnotequ( not, j ) == 6 )
				printf( " %c", j );
	 */	printf( "\n" );

		printf( "Press 'x' to exit, 'space' to pause, any to continue.\n" );
		// check keyboard input
		if ( kbhit() )
		{
			j = getch();
			if ( j == 'x' || j == 'X' )
				break;
			if ( j == ' ' )
			{
				printf( "How to decode this flamedoku? (press any key to continue.)\n" );
				getch();
				clrscr();
			}
		}
	}
//	paintflm6( 2 );
//	paintflm6( 3 );
}

